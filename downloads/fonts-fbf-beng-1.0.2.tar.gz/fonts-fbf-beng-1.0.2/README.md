# fonts-fbf-beng
This repository contains updated version 1.0.0 of Bengali Opentype fonts,  Ani and Mitra 
These fonts are now in debian package fonts-beng-extra version 3
