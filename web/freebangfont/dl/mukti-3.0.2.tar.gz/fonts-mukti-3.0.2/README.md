MUKTI OPEN SOURCE OPEN TYPE BANGLA FONT
=======================================

This is a one of the earliest Open Source OpenType Bengali / Bangla font It was made by using good quality glyphs of GPLed font bng2-n from Cyberscape Multimedia 
<https://web.archive.org/web/20021113130716/http://www.akruti.com/freedom/>. It was made for Mukta Bangla Font project.

For detail of changes in version 3.0 please visit https://mitradranirban.github.io/fonts-mukti 

This version is a part of debian package fonts-beng-extra
